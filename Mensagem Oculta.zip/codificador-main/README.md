# Codificador/Decodificador 

<p>🔒 Criptografia de texto com Base64 e Cifra de César utilizando JavaScript. 🔒</p>

🔒 #Cifra de César🔒
<a href="https://pt.wikipedia.org/wiki/Cifra_de_C%C3%A9sar">Cifra de César</a>

🔒 Base64 🔒
<a href="https://pt.wikipedia.org/wiki/Base64">Base64</a>


## Tutorial de como usar?🤔

<p>1° Você a mensagem que vai ser codificada/decodificada na primeira caixa.</p>
<p>2° Escolha qual criptografia usar</p>
<p>3° Se a criptografia escolhida for a Cifra de César, escolha uma chave e logo em seguida selecione a sua opção. Você pode codificar ou decodificar a mensagem e depois de escolher entre as duas opções clique no botão que irá aparecer(Codificar Mensagem/Decodificar Mensagem). O resultado aparecerá no quadrado abaixo.</p>
<p>Mas se a criptografia escohida for Base64, apenas marque a opção e aperte o botão que irá aparecer.</p>


## Tecnologias Utilizadas

- [ ] **HTML** 
- [ ] **CSS** 
- [ ] **JAVASCRIPT**

## Letícia Moretti



